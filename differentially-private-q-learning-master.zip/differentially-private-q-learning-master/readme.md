The code for the paper [Privacy-preserving Q-Learning with Functional Noise in Continuous Spaces
](https://arxiv.org/abs/1901.10634)

To test the code, run
```
python dpql.py seed sigma
```

Alternatively, the step-to-step notebook guide is available on __readme.ipynb__
